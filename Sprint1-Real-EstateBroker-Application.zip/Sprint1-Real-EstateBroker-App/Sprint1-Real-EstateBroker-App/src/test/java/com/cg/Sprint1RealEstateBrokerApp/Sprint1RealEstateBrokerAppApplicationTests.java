package com.cg.Sprint1RealEstateBrokerApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprint1RealEstateBrokerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
