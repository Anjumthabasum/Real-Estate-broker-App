package com.cg.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.entity.User;
import com.cg.service.IUserService;


@RestController
@RequestMapping("users")
public class IUserController 
{
	@Autowired
	private IUserService userService;
	
	@PostMapping
	public String addNewUser(@RequestBody User u) {
		return userService.addNewUserService(u);
	}
	
	@GetMapping
	public List<User>getAllUser(){
		return userService.allusersService();
	}
	
	@GetMapping("/{Role}")
	public List<User> searchByType(@PathVariable("Role") String role) {
		return userService.searchUserByrole(role);	
	}
	
	@PutMapping("/{userid}")
	public String updateUser(@PathVariable("userid") int userid, @RequestBody User u) {
		return userService.updateUserService(userid, u);	
	}
	
	@GetMapping("/userid/{userid}")
	public User searchById(@PathVariable("userid") int userid) {
		return userService.searchUserByUserId(userid);
	}
	
	@PostMapping("/login")
	public String login(@RequestBody User u) {
		return userService.login(u.getUserid(), u.getPassword());
	}
	
	@GetMapping("/logout/userid/{userid}")
	public String logout() {
		return userService.logout();
	}
}