package com.cg.controller;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.entity.Deal;
import com.cg.service.IDealService;


@RestController
@RequestMapping("deals")
public class IDealController 
{
	@Autowired
	private IDealService dealService;
	

	@PostMapping("/{userid}/{propId}")
	public String addNewDeal(@RequestBody Deal d,@PathVariable("userid")int userid, @PathVariable("propId")int propId) {
		return dealService.addNewIDealService(d, userid, propId);
	}
	
	@GetMapping
	public List<Deal>getAllDeals(){
		return dealService.getlistAllDealsService();
	}

	@GetMapping("/dealDate/{dealDate}")
	public List<Deal>searchByDate(@PathVariable("dealDate")String dealDate){
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy"); 
		Date date=null;
		try {
			date = formatter.parse(dealDate);
		} 
		catch (ParseException e) {
			e.printStackTrace();
		}  
		return dealService.searchDealByDate(date);
		}
	
	@GetMapping("/dealId/{dealId}")
	public Deal searchById(@PathVariable("dealId")int dealId) {
	return dealService.searchDealByDealId(dealId);
	}	
}