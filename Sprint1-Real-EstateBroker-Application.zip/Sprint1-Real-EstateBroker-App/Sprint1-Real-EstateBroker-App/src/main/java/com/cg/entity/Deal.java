package com.cg.entity;


import java.time.LocalDate; 
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
@Table(name="deals")
public class Deal 
{
	@Id
	private int dealId;
	@JsonFormat(pattern = "dd-MM-yyyy")
	private LocalDate dealDate;
	private double dealCost;
	
	@OneToOne
	@JoinColumn(name="userid")
	private User user;
	
	@OneToOne
	@JoinColumn(name="propId")
	private Property property;
	
	
	public int getDealId() {
		return dealId;}
	public void setDealId(int dealId) {
		this.dealId = dealId;}
	
	public LocalDate getDealDate() {
		return dealDate;}
	public void setDealDate(LocalDate dealDate) {
		this.dealDate = dealDate;}
	
	public double getDealCost() {
		return dealCost;}
	public void setDealCost(double dealCost) {
		this.dealCost = dealCost;}
	
	public Property getProperty() {
		return property;}
	public void setProperty(Property property) {
		this.property = property;}
	
	public User getUser() {
		return user;}
	public void setUser(User user) {
		this.user = user;}
}