package com.cg.service.impl;


import java.util.List; 
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.entity.Property;
import com.cg.entity.User;
import com.cg.exception.PropertyNotFoundException;
import com.cg.repository.IPropertyRepository;
import com.cg.repository.IUserRepository;
import com.cg.service.IPropertyService;


@Component
@Transactional
public class IPropertyServiceImpl implements IPropertyService
{
	@Autowired
	private IPropertyRepository propRepo;
	
	@Autowired
	private IUserRepository userRepo;

	@Override
	public String addNewIPropertyService(Property p, int userid) 
	{
		User u = userRepo.findById(userid).get();
		p.setUser(u);
		p=propRepo.save(p);
		return "Property Added successfully";
	}

	@Override
	public String updatePropertyService(Property p,int propId) 
	{
		Property p1=propRepo.findById(propId).get();
		p1.setOfferType(p.getOfferType());
		p1.setOfferCost(p.getOfferCost());
		p1.setStatus(p.isStatus());
		p1.setAreaSqft(propId);
		return "Property details updated successfully";
	}

	@Override
	public List<Property> getlistAllPropertiesService()
	{
		List<Property> list=propRepo.findAll();
		return list;
	}
	
	@Override
	public List<Property> searchPropertyBycity(String city) 
	{
		List<Property> p=propRepo.findBycity(city);
		return p;
	}

	@Override
	public List<Property> searchPropertyByOfferType(String offerType) 
	{
		List<Property> p1=propRepo.findByOfferType(offerType);
		return p1;
	}

	@Override
	public List<Property> searchPropertyByminCost(double minCost) 
	{
		List<Property> p2=propRepo.findByminCost(minCost);
		return p2;
	}

	@Override
	public List<Property> searchPropertyBymaxCost(double maxCost) 
	{
		List<Property> p3=propRepo.findBymaxCost(maxCost);
		return p3;
	}

	@Override
	public List<Property> searchPropertyByconfiguration(String configuration) 
	{
		List<Property> p4=propRepo.findByconfiguration(configuration);
		return p4;
	}

	@Override
	public Property searchPropertyByPropId(int propId) 
	{
		Property p5= propRepo.findById(propId).orElseThrow(()->new PropertyNotFoundException("Property cannot be found"));
		return p5;
	}
}