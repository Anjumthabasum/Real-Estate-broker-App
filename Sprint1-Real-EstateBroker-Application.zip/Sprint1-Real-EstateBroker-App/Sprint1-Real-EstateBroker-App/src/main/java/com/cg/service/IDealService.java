package com.cg.service;


import java.util.Date;
import java.util.List;
import com.cg.entity.Deal;


public interface IDealService 
{	
	public String addNewIDealService(Deal d, int userid, int propid);
	List<Deal> getlistAllDealsService();
	List<Deal>searchDealByDate(Date dealDate);
	Deal searchDealByDealId(int dealId);
}