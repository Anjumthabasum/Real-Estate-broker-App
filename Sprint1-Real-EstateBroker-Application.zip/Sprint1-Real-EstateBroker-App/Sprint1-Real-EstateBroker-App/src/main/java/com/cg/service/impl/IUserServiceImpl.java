package com.cg.service.impl;


import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.entity.User;
import com.cg.exception.LoginException;
import com.cg.exception.UserNotFoundException;
import com.cg.repository.IUserRepository;
import com.cg.service.IUserService;


@Component
@Transactional
public class IUserServiceImpl implements IUserService
{
	@Autowired
	private IUserRepository userRepo;

	@Override
	public String addNewUserService(User u)
	{
		u=userRepo.save(u);
		return "New User Added";
	}

	@Override
	public List<User> searchUserByrole(String role) 
	{
		List<User> list=userRepo.findByRole(role);
		return list;
	}

	@Override
	public List<User> allusersService()
	{
		List<User> list= userRepo.findAll();
		return list ;
	}

	@Override
	public String updateUserService(int userid, User u) 
	{
		User u1=userRepo.findById(userid).get();
		u1.setEmail(u.getEmail());
		u1.setMobile(u.getMobile());
		u1.setCity(u.getCity());
		u1.setPassword(u.getPassword());
		u1.setUserName(u.getUserName());
		return "User details updated successfully";
	}

	@Override
	public User searchUserByUserId(int userid) 
	{
		User u2= userRepo.findById(userid).orElseThrow(()->new UserNotFoundException("Invalid User"));
		return u2;
	}

	@Override
	public String login(int userid, String password) 
	{
		User user=userRepo.findByUserid(userid);
		if(user==null) {
			throw new LoginException("Invalid Credentials");
		}
		else if(!user.getPassword().equals(password)) {
			throw new LoginException("Invalid Credentials");
		}
		return "Login Successfully...";
	}

	@Override
	public String logout()
	{
		return "Logged out Successfully...";
	}	
}