package com.cg.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.entity.Property;
import com.cg.service.IPropertyService;


@RestController
@RequestMapping("users/{userid}/properties")
public class IPropertyController 
{
	@Autowired
	private IPropertyService propertyService;
	
	@PostMapping
	public String addNewProperty(@RequestBody Property p,@PathVariable("userid")int userid) {
		return propertyService.addNewIPropertyService(p, userid);		
	}
	
	@PutMapping("/{propId}")
	public String updateProperty(@PathVariable("propId")int propId,@RequestBody Property p) {
		return propertyService.updatePropertyService(p, propId);
	}
	
	@GetMapping
	public List<Property>getAllProperties(){
		return propertyService.getlistAllPropertiesService();
	}
	
	@GetMapping("/city/{city}")
	public List<Property>searchBycity(@PathVariable("city")String city){
		return propertyService.searchPropertyBycity(city);
	}
	
	@GetMapping("/offerType/{offerType}")
	public List<Property>searchPropertyByofferType(@PathVariable("offerType")String offerType){
		return propertyService.searchPropertyByOfferType(offerType);
	}
	
	@GetMapping("/minCost/{minCost}")
	public List<Property>searchPropertyByminCost(@PathVariable("minCost")double minCost){
		return propertyService.searchPropertyByminCost(minCost);
	}
	
	@GetMapping("/maxCost/{maxCost}")
	public List<Property>searchPropertyBymaxCost(@PathVariable("maxCost")double maxCost){
		return propertyService.searchPropertyBymaxCost(maxCost);
	}
	
	@GetMapping("/configuration/{configuration}")
	public List<Property>searchPropertyByconfiguration(@PathVariable("configuration")String configuartion){
		return propertyService.searchPropertyByconfiguration(configuartion);
	}
	
	@GetMapping("/propId/{propId}")
	public Property searchById(@PathVariable("propId") int propId) {
		return propertyService.searchPropertyByPropId(propId);
	}
}