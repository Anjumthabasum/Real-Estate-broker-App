package com.cg.service;

import java.util.List; 
import com.cg.entity.User;


public interface IUserService 
{
	String addNewUserService(User u);
	List<User> searchUserByrole(String role);
	List<User>allusersService();
	String updateUserService(int userid,User u);
	User searchUserByUserId(int userid);
	String login(int userid ,String password);
	String logout();
}