package com.cg.exception;

public class DealNotFoundException extends RuntimeException 
{	
	public DealNotFoundException() {
	}
	
	public DealNotFoundException(String msg) {
		super(msg);
	}
}