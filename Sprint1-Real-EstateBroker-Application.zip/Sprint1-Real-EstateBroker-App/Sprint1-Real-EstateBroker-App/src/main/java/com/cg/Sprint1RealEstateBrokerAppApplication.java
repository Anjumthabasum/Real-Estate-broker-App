package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprint1RealEstateBrokerAppApplication 
{
	public static void main(String[] args) {
		SpringApplication.run(Sprint1RealEstateBrokerAppApplication.class, args);
	}
}
