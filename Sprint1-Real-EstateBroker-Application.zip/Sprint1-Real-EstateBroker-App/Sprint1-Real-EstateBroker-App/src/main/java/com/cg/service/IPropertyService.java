package com.cg.service;


import java.util.List;
import com.cg.entity.Property;


public interface IPropertyService 
{
	public String addNewIPropertyService(Property p, int userid);
	public String updatePropertyService(Property p,int propId);
	List<Property> getlistAllPropertiesService();
	List<Property>searchPropertyBycity(String city);
	List<Property>searchPropertyByOfferType(String offerType);
	List<Property>searchPropertyByminCost(double minCost);
	List<Property>searchPropertyBymaxCost(double maxCost);
	List<Property>searchPropertyByconfiguration(String configuration);
	Property searchPropertyByPropId(int propId); 
}