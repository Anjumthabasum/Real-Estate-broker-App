package com.cg.service.impl;


import java.util.Date;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.entity.Deal;
import com.cg.entity.Property;
import com.cg.entity.User;
import com.cg.exception.BadRequestException;
import com.cg.exception.DealNotFoundException;
import com.cg.repository.IDealRepository;
import com.cg.repository.IPropertyRepository;
import com.cg.repository.IUserRepository;
import com.cg.service.IDealService;


@Component
@Transactional
public class IDealServiceImpl implements IDealService
{
	@Autowired
	private IPropertyRepository propRepo;
	
	@Autowired
	private IUserRepository userRepo;
	
	@Autowired
	private IDealRepository dealRepo;

	@Override
	public String addNewIDealService(Deal d, int userid, int propId) 
	{
		User u= userRepo.findById(userid).get();
		Property p= propRepo.findById(propId).get();
		if(!u.getRole().equals("Customer")) 
		{
			throw new BadRequestException("Broker cannot make the deal");
		}
		
		d.setUser(u);
		d.setProperty(p);
		d=dealRepo.save(d);
		
		return "Deal completed successfully !!!";
	}

	@Override
	public List<Deal> getlistAllDealsService() 
	{
		List<Deal> list=dealRepo.findAll();
		return list;                                                                   
	}

	@Override
	public List<Deal> searchDealByDate(Date dealDate) 
	{
		List<Deal> list1=dealRepo.searchDate(dealDate);
		return list1;
	}

	@Override
	public Deal searchDealByDealId(int dealId) 
	{
		Deal d2=dealRepo.findById(dealId).orElseThrow(()->new DealNotFoundException("Deal cannot be found"));
		return d2;
	}
}