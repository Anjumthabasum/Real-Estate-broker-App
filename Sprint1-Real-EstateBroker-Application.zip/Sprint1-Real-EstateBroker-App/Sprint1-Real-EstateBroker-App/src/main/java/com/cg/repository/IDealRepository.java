package com.cg.repository;


import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cg.entity.Deal;


@Repository
public interface IDealRepository extends JpaRepository<Deal, Integer>
{
	@Query(value = "select * from deals where deal_date = :date", nativeQuery = true)
	public List<Deal>searchDate( @Param("date")  Date dealDate);
}