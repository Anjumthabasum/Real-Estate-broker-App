package com.cg.repository;


import java.util.List; 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.entity.Property;


@Repository
public interface IPropertyRepository extends JpaRepository<Property, Integer>
{
	public List<Property> findBycity(String city);
	public List<Property> findByOfferType(String offerType);
	public List<Property> findByminCost(double minCost);
	public List<Property> findBymaxCost(double maxCost);
	public List<Property> findByconfiguration(String configuration);
}